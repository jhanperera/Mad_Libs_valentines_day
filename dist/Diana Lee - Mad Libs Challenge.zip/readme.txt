=== Madlibs for Valentine's Day ===
* Contributors: 
- Diana Lee (https://github.com/dianalee1022)
- Jhan Perera (https://github.com/jhanperera)

=== Description ===
This web application is built so users can play a valentine’s day themed madlibs game and see funny and creative results based on their inputs as a part of TopCoder’s Flood of Love Valentine’s Day Fun Challenge.

=== Installation ===
You don’t need any special installation to start this web application. Simply find the ‘index.html’ file and open it using one of your favorite web browsers!

=== License ===

Copyright 2017 Diana Lee & Jhan Perera

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.